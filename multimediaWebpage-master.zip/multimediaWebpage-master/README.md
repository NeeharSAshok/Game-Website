# GameCritic #
A game review site that provides spoiler free information to the user about the game the user wants. <br>
Created as part of a multimedia project.<br>
Work done by myself, Arvindh M, Sohan.<br>
To view the site, clone the repository to your local system and run the index.html.<br><br>
PREVIEW OF GAMECRITIC:<br><br>
![GameCritic Website](https://i.imgur.com/A2twMe8.jpeg)
![GameCritic Website](https://i.imgur.com/V9sWvMH.jpeg)
![GameCritic Website](https://i.imgur.com/zxb2rHF.jpeg)
